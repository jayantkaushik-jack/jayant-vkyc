VKYC Amber Resolution Layer — Handoff Bundle
=============================================

Read this order:

1. VKYC_Amber_Design_Handoff.docx
   Start here. Self-contained design-handoff doc — product context, explicit
   scope (visual/UI polish only, not prototype logic), product framing rules,
   UI surface map, full UI copy inventory, and working discipline for this
   engagement (git identity, commit rules, key handling, verification steps).

2. full_system_audit.md
   The deeper technical reference the handoff doc points to in its final
   section — every rule tree, the classification architecture, human-review
   triggers, abort/escalation flow, risk dimensions, personas, i18n, and the
   speech-to-text provider layer, all with file:line citations against the
   live codebase. Current through round 29 (refreshed 2026-08-30).

3. handoff_round27_classifier_reliability_fix_resolution.md
   handoff_round28_acreage_midpoint_bug_resolution.md
   handoff_round28_q1_bucket_definition_fixes_resolution.md
   handoff_round29_remove_end_session_confirm_dialog_resolution.md
   The four most recent per-round decision logs — what was built, what was
   verified, and any disclosed tradeoffs, for the last few rounds of work
   before this handoff.

These files assume no access to any prior chat history or account memory —
everything needed to safely pick up design work on the prototype is in the
.docx. The .md files are backup/deeper-reference material in case the new
account doesn't have this repository cloned locally.
